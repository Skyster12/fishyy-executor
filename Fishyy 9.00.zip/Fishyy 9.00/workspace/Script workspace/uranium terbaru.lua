--discord.gg/jsTYdFpx6a
loadstring(game:HttpGet("https://pastebin.com/raw/wkGAtS9c"))()